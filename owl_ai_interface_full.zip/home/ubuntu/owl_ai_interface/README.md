# Owl AI Interface (Flask)

A beautiful Owl AI web interface built with Flask.

## Features
- Modern dark UI with gradient accents
- Responsive, animated interface
- Chat UI with simulated backend
- Custom Owl logo

## Project Structure
```
src/
  main.py
  routes/
    chat.py
    user.py
  models/
    user.py
  static/
    index.html
    owl_logo.png
requirements.txt
```

## Setup
1. Create a virtual environment (recommended):
   
   python3 -m venv venv && source venv/bin/activate

2. Install dependencies:

   pip install -r requirements.txt

3. Run the app:

   python src/main.py

4. Open in browser:

   http://localhost:5000

## Notes
- The chat backend returns simulated responses. Replace logic in `src/routes/chat.py` to integrate a real LLM API.
- CORS is enabled.
- The app listens on 0.0.0.0:5000 for easy container/cloud hosting.


