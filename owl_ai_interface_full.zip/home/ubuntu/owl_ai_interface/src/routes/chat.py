from flask import Blueprint, request, jsonify
import random
import time

chat_bp = Blueprint('chat', __name__)

# Simulated AI responses for demo purposes
AI_RESPONSES = [
    "That's a fascinating question! I'm here to help you explore ideas and provide insights.",
    "I understand what you're asking. Let me break this down for you in a helpful way.",
    "Great point! Based on my analysis, here's what I think about that topic.",
    "I can definitely help you with that. Here's my perspective on the matter.",
    "That's an interesting challenge. Let me provide you with some thoughtful guidance.",
    "I appreciate your question. Here's how I would approach this problem.",
    "Excellent inquiry! I can offer several insights that might be valuable to you.",
    "I'm designed to assist with complex questions like this. Here's my analysis.",
    "Thanks for bringing this up. I can provide some useful information about that.",
    "That's a thought-provoking question. Let me share some relevant insights with you."
]

TOPIC_RESPONSES = {
    "hello": "Hello! I'm Owl AI, your intelligent assistant. I'm here to help you with questions, analysis, creative tasks, and much more. What would you like to explore today?",
    "hi": "Hi there! Welcome to Owl AI. I'm excited to assist you with whatever you need. Feel free to ask me anything!",
    "help": "I'm here to help! I can assist you with:\n• Answering questions and providing information\n• Creative writing and brainstorming\n• Problem-solving and analysis\n• Technical explanations\n• General conversation\n\nWhat would you like to work on?",
    "what can you do": "I'm a versatile AI assistant capable of:\n• Answering complex questions\n• Helping with creative projects\n• Providing analysis and insights\n• Explaining technical concepts\n• Assisting with problem-solving\n• Engaging in meaningful conversations\n\nHow can I help you today?",
    "who are you": "I'm Owl AI, an advanced artificial intelligence assistant designed to be helpful, informative, and engaging. I'm here to assist you with a wide range of tasks and questions!",
    "thank you": "You're very welcome! I'm glad I could help. Feel free to ask me anything else you'd like to know or explore.",
    "thanks": "My pleasure! I'm always here to help whenever you need assistance or have questions."
}

@chat_bp.route('/chat', methods=['POST'])
def chat():
    try:
        data = request.get_json()
        
        if not data or 'message' not in data:
            return jsonify({'error': 'Message is required'}), 400
        
        user_message = data['message'].strip().lower()
        
        # Simulate processing time
        time.sleep(0.5)
        
        # Check for specific topics
        response = None
        for topic, topic_response in TOPIC_RESPONSES.items():
            if topic in user_message:
                response = topic_response
                break
        
        # If no specific topic match, use a random response
        if not response:
            response = random.choice(AI_RESPONSES)
        
        return jsonify({
            'response': response,
            'timestamp': time.time()
        })
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@chat_bp.route('/chat/history', methods=['GET'])
def get_chat_history():
    # In a real application, this would fetch from a database
    return jsonify({
        'history': [],
        'message': 'Chat history feature coming soon!'
    })

@chat_bp.route('/chat/clear', methods=['POST'])
def clear_chat():
    # In a real application, this would clear the user's chat history
    return jsonify({
        'message': 'Chat history cleared successfully!'
    })

